const Chart = (() => {
    const init = {
        // type 에 의존하는 속성값들
        // - renderItem (renderForTypes 변수 참조.)
        // - 항상최솟값을 같는 key 값을 반환하는 함수. (getMinForTypes 참조)
        // - 항상최대값을 같는 key 값을 반환하는 함수. (getMaxForTypes 참조)
        // - style의 일부 속성들

        globalStyle: {
            backgroundColor: '#f5f5f5',
            // yLabelAlign
            // : right
            // : left
            yLabelAlign: "right",
            yLabelWidth: 100,

            // xLabelAlign
            // : top
            // : bottom
            xLabelAlign: "bottom",
            xLabelHeight: 30,

            textColor: '#fff',
            labelColor: '#5d5d5d',
            axisColor: '#999',
            splitAxisColor: 'rgba(0,0,0,0.05)',

            tooltipTitleColor: '#333',
            tooltipBackgroundColor: 'rgba(0,0,0,0.6)',
            tooltipXAlign: 'left',
            tooltipYAlign: 'top',
            tooltipMinWidth: 100,

            focusBackgroundColor: 'rgba(0, 175, 255, 0.1)',
            focusBorderColor: 'rgba(0, 175, 255, 0.2)'
        },

        layerType: 'candle', // candle , line
        layerStyle: {
            candle: {
                incrementItemColor: '#14b143',
                decrementItemColor: '#ef232a',
                minBodyWidth: 6
            },
            line: {
                itemColor: '#000000'
            }
        },

        // 라벨속성에 따라 값이 맞춰진다.
        grid: {
            top: 0,
            right: 100,
            bottom: 30,
            left: 0
        },

        padding: {
            top: 50,
            right: 0,
            bottom: 50,
            left: 0
        },
        dateFormatter: "MM-dd HH:mm"
    };
    // theme 은 globalStyle layerStyle 을 지정 가능
    const themes = {
        gray: {
            globalStyle: {},
            layerStyle: {
                candle: {},
                line: {}
            }
        },
        dark: {
            globalStyle: {
                backgroundColor: '#151515',
                labelColor: '#aaa',
                splitAxisColor: 'rgba(255,255,255,0.1)',

                tooltipBackgroundColor: 'rgba(255,255,255,0.1)'
            },
            layerStyle: {
                candle: {},
                line: {
                    itemColor: '#999'
                }
            }
        }
    };

    // 레이어 타입에 따른 메소드 정의
    const renderForTypes = {
        candle: ({
            ctx,
            itemWidth,
            transform,
            style
        }, {
            open,
            close,
            high,
            low
        }) => {
            let y = transform(Math.max(open, close)),
                h = transform(Math.min(open, close)) - y,
                t = transform(high),
                b = transform(low);

            ctx.strokeStyle = close > open ? style.incrementItemColor : style.decrementItemColor;
            ctx.fillStyle = close > open ? style.incrementItemColor : style.decrementItemColor;

            if (itemWidth <= style.minBodyWidth) {
                ctx.beginPath();
                ctx.moveTo(f(itemWidth * 0.5), f(t));
                ctx.lineTo(f(itemWidth * 0.5), f(b));
                ctx.closePath();
                ctx.stroke();
                return;
            }

            ctx.beginPath();
            ctx.moveTo(f(itemWidth * 0.5), f(t));
            ctx.lineTo(f(itemWidth * 0.5), f(y));
            ctx.closePath();
            ctx.stroke();

            ctx.beginPath();
            ctx.moveTo(f(itemWidth * 0.5), f(y + h));
            ctx.lineTo(f(itemWidth * 0.5), f(b));
            ctx.closePath();
            ctx.stroke();

            ctx.fillRect(2, f(y), f(itemWidth - 4), f(h));
            ctx.strokeRect(2, f(y), f(itemWidth - 4), f(h));
        },
        line: ({
            ctx,
            itemWidth,
            transform,
            style
        }, data) => {
            if (data === null) return;
            let y = transform(data);

            ctx.fillStyle = style.itemColor;
            ctx.strokeStyle = style.itemColor;
            ctx.lineTo(f(itemWidth * 0.5), y);
        },
    };
    const tooltipForTypes = {
        candle: ({
            title,
            data,
            formatter = v => v
        }) => data === null ? null : [`${title.open || 'Open'} ${formatter(data.open)}`, `${title.close || 'Close'} ${formatter(data.close)}`, `${title.low || 'Low'} ${formatter(data.low)}`, `${title.high || 'High'} ${formatter(data.high)}`],
        line: ({
            title,
            data,
            formatter = v => v,
        }) => data === null ? null : `${title} ${formatter(data)}`
    };
    const getMinForTypes = {
        candle: item => item.low,
        line: item => item
    };
    const getMaxForTypes = {
        candle: item => item.high,
        line: item => item
    };

    // 유틸 메소드
    const map = (n, a, b, c, d) => ((n - a) / (b - a)) * (d - c) + c;
    const f = Math.floor;
    const overwrite = (target, base) => {
        if (typeof target !== 'object' || target === null) target = {};

        let bKeys = Object.keys(base);

        for (let i = 0, l = bKeys.length; i < l; i++) {
            let key = bKeys[i];
            if (target[key] === undefined) target[key] = base[key];
        }

        return target;
    };
    const applyDateFormatter = (d, f) => {
        return f.replace(/(yyyy|yy|MM|dd|hh|mm|ss)/gi, function (ch) {
            switch (ch) {
                case "yyyy":
                    return d.getFullYear();
                case "yy":
                    return zf(d.getFullYear() % 1000, 2);
                case "MM":
                    return zf(d.getMonth() + 1, 2);
                case "dd":
                    return zf(d.getDate(), 2);
                case "HH":
                    return zf(d.getHours(), 2);
                case "hh":
                    return zf((h = d.getHours() % 12) ? h : 12, 2);
                case "mm":
                    return zf(d.getMinutes(), 2);
                case "ss":
                    return zf(d.getSeconds(), 2);
                default:
                    return ch;
            }
        });
    };
    const zf = (e, l) => {
        if (typeof e === "number") e = e.toString();
        if (typeof e === "string") {
            var s = '',
                i = 0;
            while (i++ < l - e.length) {
                s += "0";
            }
            return s + e;
        }
    };

    const $keys = [];

    const $getOnTimeline = {};
    const $getOnViewport = {};

    const $getTimeline = {};
    const $getViewport = {};

    const $share = {};

    const $onForShare = (type, $key) => {
        let arr = $share[$key];
        let obj;

        if (type === 'timeline') obj = $getOnTimeline;
        else if (type === 'viewport') obj = $getOnViewport;

        for (let i = 0; i < arr.length; i++) {
            obj[arr[i]]();
        }
    };
    class Chart {
        constructor(domId) {
            let wrapper = document.getElementById(domId);
            if (wrapper === null) {
                console.error(`Candle.js:: can't found DOM element (#${domId})`);
                return;
            }

            const $key = this.$key = (
                () => {
                    let k;
                    while (k === undefined || $keys.includes(k)) {
                        k = `${Math.random()}::${Math.random()}::${Math.random()}`;
                    }
                    $keys.push(k);
                    $share[k] = [];

                    return k;
                }
            )();

            let theme;

            const initLayerStyle = {};

            /* wrapper style settings */
            wrapper.style.position = 'relative';

            let canvasStack = [];
            // 캔버스 생성, wrapper 에 append 후 object로 dom 객체와 context 반환.
            const makeCanvas = (zIndex = 0) => {
                let canvas = document.createElement('canvas');
                let context = canvas.getContext('2d');

                canvas.style.position = 'absolute';
                canvas.style.top = 0;
                canvas.style.left = 0;

                canvas.style.zIndex = zIndex;

                canvas.width = wrapper.clientWidth;
                canvas.height = wrapper.clientHeight;
                wrapper.appendChild(canvas);

                context.translate(0.5, 0.5);
                canvasStack.push(canvas);

                return {
                    canvas,
                    context
                };
            };

            /* Variable 정의 */
            let layers = {};
            let viewport = []; /* 0 : start / 1 : end */
            let timeline = [];
            let {
                grid,
                padding,
                globalStyle,
                dateFormatter
            } = init;
            let min;
            let max;

            // X,Y 축 캔버스 Context 정의
            // 라벨이 업데이트 될 때.
            // - setViewport 로 뷰포트가 업데이트 되었을 경우.
            // - setTimeline 로 x축 값이 변경 되었을 경우.
            // - addLayer 로 layer의 속성이 변경 되었을 경우.
            const yLabelCtx = makeCanvas().context;
            const xLabelCtx = makeCanvas().context;

            const floatCtx = makeCanvas().context;
            const tooltipCtx = makeCanvas(10000).context;

            // 속성공유 메소드
            const unshare = () => {
                $getTimeline[$key] = () => timeline;
                $getViewport[$key] = () => viewport;

                for (let key in $share) {
                    let i = $share[key].indexOf($key);
                    if (i === -1) continue;
                    else {
                        $share[key].splice(i, 1);
                        break;
                    }
                }
            };
            const share = t => {
                if (t instanceof Chart !== true) return;
                $getTimeline[t.$key] = () => timeline;
                $getViewport[t.$key] = () => viewport;

                for (let key in $share) {
                    let i = $share[key].indexOf(t.$key);
                    if (i === -1) continue;
                    else {
                        console.error("Candle.js:: 이미 공유중인 객체입니다.");
                        return;
                    }
                }
                $share[$key].push(t.$key);
            };

            const onTimeline = $getOnTimeline[$key] = () => {
                reloadTooltip();
                renderXLabel();
            };

            const onViewport = $getOnViewport[$key] = () => {
                updateMinMax();
                renderAll();
            };

            unshare();

            // 레이어 메소드
            const addLayer = (name, {
                type,
                data,
                style
            }) => { /* 라이브러리에 관련된 객체셋팅. */
                if (layers[name] !== undefined) {
                    return;
                }
                let layer = makeCanvas();

                layer.type = type || init.layerType;
                layer.data = data || [];
                layer.style = overwrite(style, initLayerStyle[layer.type]);

                layers[name] = layer;

                updateMinMax();
                renderAll();
            };
            const setLayer = (name, {
                type,
                data,
                style
            }) => {
                let layer = layers[name];

                // type 변경시 type에 영향이 가는 레이어속성들을 새로설정.
                const baseStyle =
                    (type !== undefined && type !== layer.type) ?
                    initLayerStyle[type] :
                    layer.style;

                layer.type = type || layer.type;
                layer.data = data || layer.data;
                layer.style = overwrite(style, baseStyle);

                updateMinMax();

                render(layer);
                reloadTooltip();
            };
            const layerMap = (func, formatter) => {
                let lKeys = Object.keys(layers);
                let rObj = [];

                for (let i = 0; i < lKeys.length; i++) {
                    let key = lKeys[i],
                        r = func(layers[key], key);
                    if (formatter) rObj[formatter(key)] = r;
                    else rObj.push(r);
                }

                return rObj;
            };

            // 뷰포트 메소드
            const setViewport = (s, e) => {
                viewport[0] = Math.min(s, e);
                viewport[1] = Math.max(s, e);

                onViewport();
                // share 객체와의 싱크를 맞추기 위한 로직
                $onForShare('viewport', $key);
            };
            const getViewport = () => ([viewport[0], viewport[1]]);

            // 타임라인 메소드
            const setTimeline = pTimeline => {
                timeline = [];
                for (let i = 0, l = pTimeline.length; i < l; i++) {
                    timeline.push(new Date(pTimeline[i]));
                }

                onTimeline();
                // share 객체와의 싱크를 맞추기 위한 로직
                $onForShare('timeline', $key);
            };

            const setDateFormatter = f => {
                dateFormatter = f;
                renderXLabel();
            }

            // 패딩 메소드
            const setPadding = pPadding => {
                padding = overwrite(pPadding, padding);
                layerMap(layer => render(layer));
            };

            // 스타일 메소드
            const setStyle = pStyle => {
                globalStyle = overwrite(pStyle, globalStyle);

                grid.top = globalStyle.xLabelAlign === 'top' ? globalStyle.xLabelHeight : 0;
                grid.bottom = globalStyle.xLabelAlign === 'bottom' ? globalStyle.xLabelHeight : 0;

                grid.left = globalStyle.yLabelAlign === 'left' ? globalStyle.yLabelWidth : 0;
                grid.right = globalStyle.yLabelAlign === 'right' ? globalStyle.yLabelWidth : 0;

                renderAll();
            }

            const getTransformSize = () => ({
                tWidth: wrapper.clientWidth - grid.right - grid.left,
                tHeight: wrapper.clientHeight - grid.bottom - grid.top,
            });

            const updateMinMax = () => {
                let arr = layerMap(layer => {
                    let {
                        data,
                        type
                    } = layer;
                    let viewport = $getViewport[$key]();

                    let getMin = getMinForTypes[type];
                    let getMax = getMaxForTypes[type];

                    let min = Infinity,
                        max = -Infinity;

                    for (let i = viewport[0], l = viewport[1]; i < l; i++) {
                        if (data[i] === null) continue;

                        let _min = getMin(data[i]);
                        let _max = getMax(data[i]);

                        if (min > _min) min = _min;
                        if (max < _max) max = _max;
                    }

                    return {
                        min,
                        max
                    };
                });

                let _min = Infinity,
                    _max = -Infinity;

                for (let i = 0; i < arr.length; i++) {
                    if (arr[i].min < _min) _min = arr[i].min;
                    if (arr[i].max > _max) _max = arr[i].max;
                }

                min = _min;
                max = _max;
            };

            const renderXLabel = () => {
                let timeline = $getTimeline[$key]();
                let viewport = $getViewport[$key]();

                let {
                    xLabelHeight,
                    xLabelAlign,
                } = globalStyle;

                let width = wrapper.clientWidth,
                    height = wrapper.clientHeight;

                // Transform Size
                let {
                    tWidth,
                    tHeight,
                } = getTransformSize();

                let itemWidth = (tWidth) / (viewport[1] - viewport[0]);

                xLabelCtx.save();
                xLabelCtx.clearRect(-10, -10, width + 10, height + 10);
                xLabelCtx.translate(grid.left, 0);

                // Xlabel Settings
                xLabelCtx.textBaseline = "middle";
                xLabelCtx.textAlign = "left";
                xLabelCtx.font = "12px 'Apple SD Gothic Neo',arial,sans-serif";

                let xLineY = f(grid.top + (height - xLabelHeight));
                let xLineLabelY = xLabelAlign === 'top' ? (xLabelHeight / 2) : height - (xLabelHeight / 2);
                let xAxisY = xLabelAlign === 'bottom' ? xLineY : grid.top;

                xLabelCtx.strokeStyle = globalStyle.axisColor;
                xLabelCtx.beginPath();
                xLabelCtx.moveTo(0, xAxisY);
                xLabelCtx.lineTo(tWidth, xAxisY);
                xLabelCtx.closePath();
                xLabelCtx.stroke();

                for (let i = viewport[0], l = viewport[1], s = f((viewport[1] - viewport[0]) / 5); i < l; i++) {
                    if (viewport[0] - l === -1 || (l - i) % s === 0) {
                        let xLineLabelX = f(itemWidth * 0.5);

                        xLabelCtx.strokeStyle = globalStyle.axisColor;
                        xLabelCtx.beginPath();
                        xLabelCtx.moveTo(xLineLabelX, xAxisY + (xLabelAlign === 'bottom' ? 5 : -5));
                        xLabelCtx.lineTo(xLineLabelX, xAxisY);
                        xLabelCtx.closePath();
                        xLabelCtx.stroke();

                        xLabelCtx.strokeStyle = globalStyle.splitAxisColor;
                        xLabelCtx.beginPath();
                        xLabelCtx.moveTo(xLineLabelX, grid.top);
                        xLabelCtx.lineTo(xLineLabelX, xLineY);
                        xLabelCtx.closePath();
                        xLabelCtx.stroke();

                        xLabelCtx.fillStyle = globalStyle.labelColor;
                        xLabelCtx.fillText(
                            applyDateFormatter(timeline[i], dateFormatter),
                            f(xLineLabelX),
                            f(xLineLabelY)
                        );
                    }
                    xLabelCtx.translate(itemWidth, 0);
                }
                xLabelCtx.restore();
            };

            const renderYLabel = () => {
                let timeline = $getTimeline[$key]();
                let viewport = $getViewport[$key]();

                let {
                    yLabelWidth,
                    yLabelAlign
                } = globalStyle;

                let width = wrapper.clientWidth,
                    height = wrapper.clientHeight;

                // Transform Size
                let {
                    tWidth,
                    tHeight,
                } = getTransformSize();

                let itemWidth = (tWidth) / (viewport[1] - viewport[0]);

                yLabelCtx.save();
                yLabelCtx.clearRect(-10, -10, width + 10, height + 10);
                yLabelCtx.translate(0, tHeight + grid.top);

                // Ylabel Settings
                yLabelCtx.textBaseline = "middle";
                yLabelCtx.textAlign = yLabelAlign === 'left' ? 'right' : 'left';
                yLabelCtx.font = "12px 'Apple SD Gothic Neo',arial,sans-serif";

                let yLineX = f(yLabelAlign === 'left' ? yLabelWidth : width - yLabelWidth);

                yLabelCtx.beginPath();

                yLabelCtx.strokeStyle = globalStyle.axisColor;

                yLabelCtx.moveTo(yLineX, 0);
                yLabelCtx.lineTo(yLineX, -tHeight);
                yLabelCtx.closePath();
                yLabelCtx.stroke();

                let split = 10;
                let temp = (max - min) / split;
                let tempIncrease = 10;
                let tempSplit = 1;

                while (tempSplit + tempIncrease < temp) {
                    tempSplit *= tempIncrease;
                }

                let rd = f(min - (min % tempSplit));

                yLabelCtx.fillStyle = globalStyle.labelColor;

                for (let i = 0; i < split; i++) {
                    let d = rd + tempSplit * i;
                    if (d > max) break;
                    else if (d < min) continue;

                    let y = -map(d, min, max, 0, tHeight);

                    yLabelCtx.fillText(d.toString(), yLineX + (yLabelAlign === 'right' ? 5 : -5), y);

                    yLabelCtx.strokeStyle = globalStyle.splitAxisColor;
                    yLabelCtx.beginPath();
                    yLabelCtx.moveTo(grid.left, y);
                    yLabelCtx.lineTo(yLineX - 1, y);
                    yLabelCtx.closePath();
                    yLabelCtx.stroke();
                }

                yLabelCtx.restore();
            };

            // 출력 메소드
            const render = layer => {
                let timeline = $getTimeline[$key]();
                let viewport = $getViewport[$key]();

                let {
                    data,
                    type,
                    context,
                    canvas,
                    style
                } = layer;

                let width = wrapper.clientWidth,
                    height = wrapper.clientHeight;

                if (viewport[0] === undefined || viewport[1] === undefined) {
                    setViewport(0, timeline.length);
                }

                // 레이어 타입에 따른 메소드를 가져온다.
                let renderItem = renderForTypes[type];

                // Transform Size
                let {
                    tWidth,
                    tHeight,
                } = getTransformSize();

                let itemWidth = (tWidth) / (viewport[1] - viewport[0]);

                context.save();

                // Clear
                context.clearRect(-10, -10, width + 10, height + 10);

                // Translate
                context.translate(grid.left, tHeight + grid.top);

                context.beginPath();

                for (let i = viewport[0], l = viewport[1], s = f((viewport[1] - viewport[0]) / 5); i < l; i++) {
                    renderItem({
                        ctx: context,
                        itemWidth,
                        transform: v => -map(v, min, max, padding.top, tHeight - padding.bottom),
                        style
                    }, data[i]);
                    context.translate(itemWidth, 0);
                }
                context.stroke();
                context.closePath();

                context.restore();
            };

            const renderAll = () => {
                layerMap(layer => render(layer));

                renderXLabel();
                renderYLabel();

                reloadTooltip();
            };

            // 이벤트 리스너 등록
            // 줌 Zoom
            wrapper.addEventListener('mousewheel', e => {
                let timeline = $getTimeline[$key]();
                let viewport = $getViewport[$key]();

                let velocity = (e.deltaY / 100) * -5;
                let nextViewport = [viewport[0] + velocity, viewport[1]];

                if (nextViewport[0] < 0) {
                    nextViewport[0] = 0;
                    nextViewport[1] -= velocity;
                }
                if (nextViewport[1] > timeline.length) nextViewport[1] = timeline.length;
                if (nextViewport[0] >= nextViewport[1]) nextViewport[0] = nextViewport[1] - 1;

                setViewport(nextViewport[0], nextViewport[1]);
                focusIndex({
                    x: e.layerX,
                    y: e.layerY
                });
            });
            // 드래그 Drag
            let mousedown = false;
            let prevMouseX = null;

            wrapper.addEventListener('mousedown', e => {
                mousedown = true;
                prevMouseX = e.clientX;
            });
            window.addEventListener('mouseup', () => {
                if (mousedown === true) {
                    mousedown = false;
                    prevMouseX = null;
                }
            });
            window.addEventListener('mousemove', e => {
                let timeline = $getTimeline[$key]();
                let viewport = $getViewport[$key]();

                let delta = prevMouseX - e.clientX;
                // 이동값이 10px 이상일 경우, 좌 또는 우로 데이터 1개만큼 뷰포트 이동. (speed = 5)
                if (mousedown === true && prevMouseX !== null && Math.abs(delta) >= 10) {
                    e.preventDefault();

                    let direction = delta < 0 ? -1 : 1,
                        velocity = direction * 5,
                        nextViewport = [viewport[0] + velocity, viewport[1] + velocity];

                    if (nextViewport[0] < 0 || nextViewport[1] > timeline.length) return;

                    setViewport(nextViewport[0], nextViewport[1]);
                    prevMouseX = e.clientX;
                }
            });
            // 탐색
            wrapper.addEventListener('mousemove', e => {
                focusIndex({
                    x: e.layerX,
                    y: e.layerY
                });
            });
            wrapper.addEventListener('mouseout', e => {
                floatCtx.clearRect(-10, -10, wrapper.clientWidth + 10, wrapper.clientHeight + 10);
            });
            let previousFocusedIndex;
            const focusIndex = ({
                x,
                y
            }) => {
                let {
                    tWidth,
                    tHeight,
                } = getTransformSize();

                let timeline = $getTimeline[$key]();
                let viewport = $getViewport[$key]();

                let itemWidth = (tWidth) / (viewport[1] - viewport[0]);
                let screenIndex = Math.floor(x / itemWidth);
                let index = viewport[0] + screenIndex;

                if (previousFocusedIndex === index) {
                    return;
                }
                if (index < 0 || index >= viewport[1]) {
                    floatCtx.clearRect(-10, -10, wrapper.clientWidth + 10, wrapper.clientHeight + 10);
                    return;
                }

                floatCtx.save();

                floatCtx.clearRect(-10, -10, wrapper.clientWidth + 10, wrapper.clientHeight + 10);

                floatCtx.fillStyle = globalStyle.focusBackgroundColor;
                floatCtx.strokeStyle = globalStyle.focusBorderColor;

                floatCtx.fillRect(screenIndex * itemWidth, grid.top, itemWidth, tHeight);
                floatCtx.strokeRect(screenIndex * itemWidth, grid.top, itemWidth, tHeight);

                floatCtx.restore();

                let datas =
                    layerMap(
                        (layer, name) => layer.data[index] === 'object' ? overwrite(null, layer.data[index]) : layer.data[index],
                        name => name
                    );
                let time = new Date(timeline[index]);

                this.onSelect(time, datas);
                showTooltip(index);
            };

            let tooltipOptions = {
                show: false,
                forammters: {},
                titles: {},
                filters: [],
                mainCandle: ''
            };
            const setTooltip = (options = {}) => {
                tooltipOptions = overwrite(options, tooltipOptions);
                reloadTooltip();
            };

            let lastTooltipIndex = null;
            const reloadTooltip = () => lastTooltipIndex !== null && showTooltip(lastTooltipIndex);

            const showTooltip =
                (() => {
                    const render = ({
                        ctx,
                        texts,
                        lineHeight,
                        minWidth = globalStyle.tooltipMinWidth,
                        notRender = false
                    }) => {
                        let lineCount = 1;
                        let lineWidth = 0;
                        let space = 10;
                        let rendered = false;
                        let maxWidth = -Infinity;

                        texts.map(
                            text => {
                                let width;

                                if (Array.isArray(text.text) === true) {
                                    width = ctx.measureText(text.text.join('')).width + ((text.text.length - 1) * space);
                                } else {
                                    width = ctx.measureText(text.text).width;
                                }

                                text.width = width;

                                if (width > maxWidth) maxWidth = width;
                            }
                        );

                        for (let i = 0; i < texts.length; i++) {

                            let text = texts[i];

                            if (maxWidth < lineWidth + text.width) {

                                if (notRender !== true) {
                                    ctx.translate(0, lineHeight);
                                }
                                lineWidth = 0;
                                lineCount++;

                            }
                            if (notRender !== true) {

                                ctx.fillStyle = text.color;

                                if (Array.isArray(text.text) === true) {
                                    let l = 0;
                                    for (let j = 0; j < text.text.length; j++) {
                                        ctx.fillText(text.text[j], l + j * space, 0);
                                        l += ctx.measureText(text.text[j]).width;
                                    }
                                } else ctx.fillText(text.text, lineWidth, 0);

                            }
                            lineWidth += text.width + space;
                            rendered = true;
                        }

                        lineCount = rendered === false ? 0 : lineCount;

                        return {
                            lineCount,
                            height: lineCount * lineHeight,
                            width: Math.max(maxWidth, minWidth)
                        };
                    };
                    return (index) => {
                        let {
                            show,
                            filters,
                            formatters,
                            titles,
                            mainCandle
                        } = tooltipOptions;

                        let timeline = $getTimeline[$key]();
                        let viewport = $getViewport[$key]();

                        tooltipCtx.clearRect(-10, -10, wrapper.clientWidth + 20, wrapper.clientHeight + 20);

                        if (show !== true) return;

                        let texts = [],
                            fontSize = 13,
                            lineHeight = fontSize * 1.2;
                        // maxWidth = 300 (px)
                        ;

                        tooltipCtx.font = `${fontSize}px 'Apple SD Gothic Neo', arial, sans-serif`;
                        tooltipCtx.textBaseline = "top";

                        layerMap((layer, name) => {
                            if (filters.indexOf(name) !== -1) {
                                return;
                            }
                            let text = tooltipForTypes[layer.type]
                                ({
                                    title: titles[name] || name,
                                    formatter: formatters[name],
                                    data: layer.data[index],
                                });

                            if (text === null) return;

                            texts.push({
                                text,
                                color: layer.style.itemColor || globalStyle.textColor
                            });
                        });

                        tooltipCtx.save();

                        let rTooltip =
                            b => render({
                                ctx: tooltipCtx,
                                texts,
                                lineHeight,
                                notRender: b
                            });
                        let pVertical = 10;
                        let pHorizontal = 20;

                        let r = rTooltip(true),
                            rHeight = r.height + pVertical,
                            rWidth = r.width + pHorizontal;

                        let {
                            tWidth,
                            tHeight
                        } = getTransformSize();

                        // 타이틀 세팅
                        // const titleFont = "bold 18px 'Apple SD Gothic Neo',arial,sans-serif";
                        // tooltipCtx.save();
                        // tooltipCtx.font = titleFont;

                        // let title = applyDateFormatter(timeline[index], 'yyyy-MM-dd hh:mm:ss'),
                        //     titleWidth = tooltipCtx.measureText(title).width;

                        // rWidth = Math.max(rWidth, titleWidth + 10);
                        // tooltipCtx.restore();
                        /////////////////////////

                        tooltipCtx.translate(grid.left, grid.top);

                        if (globalStyle.tooltipXAlign === 'left') {
                            tooltipCtx.translate(5, 0);
                        } else if (globalStyle.tooltipXAlign === 'right') {
                            tooltipCtx.translate(tWidth - rWidth - 15, 0);
                        }
                        if (globalStyle.tooltipYAlign === 'top') {
                            tooltipCtx.translate(0, 5);
                        } else if (globalStyle.tooltipYAlign === 'bottom') {
                            tooltipCtx.translate(0, tHeight - rHeight - 5);
                        }

                        // // 타이틀 그리기
                        // tooltipCtx.save();

                        // tooltipCtx.font = titleFont;
                        // tooltipCtx.fillStyle = globalStyle.tooltipTitleColor;

                        // tooltipCtx.fillText(title, 0, 0);

                        // tooltipCtx.restore();
                        // /////////////////////////

                        // tooltipCtx.translate(0, 23);

                        if (mainCandle) {
                            let {
                                data,
                                style
                            } = layers[mainCandle];
                            let {
                                open,
                                close
                            } = data[index];

                            tooltipCtx.globalAlpha = 0.8;
                            tooltipCtx.fillStyle = open < close ?
                                style.incrementItemColor : style.decrementItemColor;

                            tooltipCtx.fillRect(0, 0, 10, rHeight);
                            tooltipCtx.globalAlpha = 1;

                            tooltipCtx.translate(10, 0);
                        }

                        tooltipCtx.fillStyle = globalStyle.tooltipBackgroundColor;
                        tooltipCtx.fillRect(0.5, 0, rWidth, rHeight);

                        tooltipCtx.translate(pHorizontal / 2, pVertical / 2);

                        rTooltip();

                        tooltipCtx.restore();

                        lastTooltipIndex = index;
                    };
                })();

            const updateInitLayerStyle = () => {
                initLayerStyle.candle = overwrite(theme.layerStyle.candle, init.layerStyle.candle);
                initLayerStyle.line = overwrite(theme.layerStyle.line, init.layerStyle.line);
            };
            const updateWrapperStyle = () => {
                // wrapperStyle 은 개념적으로는 globalStyle 이지만 다른 globalStyle 속성들과는 다르게 렌더링 도중에 값이 업데이트 되지않음.
                wrapper.style.backgroundColor = globalStyle.backgroundColor;
            };
            const setTheme = themeName => {
                theme = themes[themeName];

                // 전역 스타일 업데이트.
                globalStyle = overwrite(theme.globalStyle, globalStyle);

                // Wrapper 스타일 업데이트.
                updateWrapperStyle();

                // 레이어 기본 스타일 업데이트.
                updateInitLayerStyle();

                // 레이어 스타일 적용.
                layerMap(
                    (layer, name) =>
                    setLayer(name, {
                        style: initLayerStyle[layer.type]
                    })
                );

                renderXLabel();
                renderYLabel();
            };
            setTheme("gray");

            const resize = () => {
                // 모든 canvas 의 크기를 wrapper에 맞춤.
                canvasStack.map(canvas => {
                    canvas.width = wrapper.clientWidth;
                    canvas.height = wrapper.clientHeight;
                });
                renderAll();
            };

            /* return(define) public logics */
            this.addLayer = addLayer;
            this.getViewport = getViewport;
            this.setDateFormatter = setDateFormatter;
            this.setViewport = setViewport;
            this.setTimeline = setTimeline;
            this.setPadding = setPadding;
            this.setTooltip = setTooltip;
            this.setLayer = setLayer;
            this.setStyle = setStyle;
            this.setTheme = setTheme;

            this.resize = resize;
            this.render = () => renderAll();
            this.onSelect = () => {};

            this.share = share;
            this.unshare = unshare;
        }
    }
    Chart.addTheme = (name, th) => themes[name] = th;
    Chart.calculateMA = (dayCount, data) => {
        let result = [],
            arr = [],
            sum = 0;
        for (let i = 0, len = data.length; i < len; i++) {
            result[i] = null;

            arr.push(data[i]);
            sum += data[i];

            if (arr.length === dayCount) {
                result[i] = sum / dayCount;
                sum -= arr.shift();
            }
        }
        return result;
    };

    return Chart;
})();